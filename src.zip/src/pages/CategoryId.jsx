import CategoryContent from "../components/categoryContent/CategoryContent"





function CategoryId() {
  
 


  return (
    <>
  <CategoryContent />
    </>
  )
}

export default CategoryId