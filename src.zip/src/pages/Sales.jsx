import DiscountedItems from "../components/discountedItems/DiscountedItems"

function Sales() {
  return (
    <>


    <DiscountedItems />
    </>
  )
}

export default Sales