import CategoriesPage from "../components/categoriesPage/CategoriesPage"

function Categories() {
  return (
    <>
      <CategoriesPage />
    </>
  )
}

export default Categories