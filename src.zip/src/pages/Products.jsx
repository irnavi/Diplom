import ProductsPage from "../components/productsPage/ProductsPage"

function Products() {
  return (
    <>
    <ProductsPage />
    </>
  )
}

export default Products