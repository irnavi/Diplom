import CartItems from "../components/cartItems/CartItems"

function Cart() {
  return (
    <>

    <CartItems />
    </>
  )
}

export default Cart