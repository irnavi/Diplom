import NotFound from "../components/notFound/NotFound"

function Error() {
  return (
    <div>
       
        <NotFound />
       

    </div>
  )
}

export default Error